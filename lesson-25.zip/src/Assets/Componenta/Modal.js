import React from 'react';
import "../Style/Modal.css"

export function Modal({closeModal}) {
    return (
        <div>
            <div id='background'>
                <div>
                    <input type="" name="" value="" />
                    <h1>sadodjaidas</h1>
                </div>
            </div>
        </div>
    )
}
