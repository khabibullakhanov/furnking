import React from 'react'

export function Contact() {
    return (
        <div>
                
        </div>
    )
}
