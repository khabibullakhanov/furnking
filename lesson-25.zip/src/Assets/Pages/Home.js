import React from 'react'
import { Header } from '../Componenta/Header'

export function Home() {
    return (
        <div>
            <Header/>
        </div>
    )
}
