// const profileImg = JSON.parse(localStorage.getItem("profileImg" || "[]"))

// export const reProfile = (state = profileImg, action) => {
//     switch (action.type) {
//         case "ADD_PROFILE_IMG":
//             return [state, action.payload]
//     }
// }


// export const acProfile = (profileImg) => ({
//     type: "ADD_PROFILE_IMG",
//     payload: profileImg,
// }) 













